<?php

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Command;

class planExpire extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'plan';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'planExpire every all mounth';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $users = User::where('verified', 1)->get();  // Retrieve users who are not verified
        foreach ($users as $user) {
            $user->update([
                'verified' => 0  // Update verification status to verified (usually 1)
            ]);
        }
    }
}
